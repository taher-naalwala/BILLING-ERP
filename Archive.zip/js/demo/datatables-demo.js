$(document).ready(function () {
  $('#dataTable').DataTable({
    "ordering": false,
    dom: 'Bfrtip',
    buttons: [
      'print',
      'excelHtml5',

      'pdfHtml5'
    ]
  });
});

$(document).ready(function () {
  $('#dataTable2').DataTable({
    "ordering": false,
    dom: 'Bfrtip',
    buttons: [
      'print',
      'excelHtml5',

      'pdfHtml5'
    ]
  });
});

// Call the dataTables jQuery plugin
$(document).ready(function () {
  $('#dataTable1').DataTable({
    "ordering": false,

    dom: 'Bfrtip',
    buttons: [

      'print',
      'excelHtml5',

      'pdfHtml5'

    ]
  });
});
